import 'package:career/core/constant/class/app_color.dart';
import 'package:career/features/tasks/presentation/getx/controller/tasks_controller.dart';
import 'package:career/features/tasks/presentation/widget/custom_card_task.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/constant/class/app_string.dart';
import '../../../../core/widget/custom_app_bar.dart';

class TasksScreen extends GetView<TasksController> {
  const TasksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FC),
      appBar: PreferredSize(
        preferredSize: const Size(double.infinity, 70),
        child: CustomAppBar(text: AppString.task.tr),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Obx(() {
            if (controller.isLoading.value && controller.tasks.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }

            if (controller.tasks.isEmpty) {
              return RefreshIndicator(
                onRefresh: controller.fetchTasks,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: [
                    const SizedBox(height: 8),
                    _TopHeader(controller: controller),
                    const SizedBox(height: 24),
                    _EmptyTasksState(onRefresh: controller.fetchTasks),
                    const SizedBox(height: 40),
                  ],
                ),
              );
            }

            final visibleTasks = controller.filteredTasks;
            final latestTask = controller.latestTask;

            return RefreshIndicator(
              onRefresh: controller.fetchTasks,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  _TopHeader(controller: controller),
                  const SizedBox(height: 18),
                  if (latestTask != null) ...[
                    CustomTaskCard(
                      task: latestTask,
                      featured: true,
                      onStatusChanged: (status) => controller.updateTaskStatus(
                        task: latestTask,
                        status: status,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                  _AllTasksHeader(count: visibleTasks.length),
                  const SizedBox(height: 14),
                  if (visibleTasks.isEmpty)
                    _FilteredEmptyState(
                      onClearFilter: () => controller.setFilter(TaskFilter.all),
                    )
                  else
                    ...visibleTasks.skip(1).map(
                          (task) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: CustomTaskCard(
                          task: task,
                          onStatusChanged: (status) => controller.updateTaskStatus(
                            task: task,
                            status: status,
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _AllTasksHeader extends StatelessWidget {
  const _AllTasksHeader({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          AppString.allTasks.tr,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
            color: AppColor.black,
          ),
        ),
        const SizedBox(width: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: AppColor.primaryColor.withOpacity(0.10),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: AppColor.primaryColor.withOpacity(0.14),
            ),
          ),
          child: Text(
            '$count',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: AppColor.primaryColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Container(
            height: 1.2,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              gradient: LinearGradient(
                colors: [
                  AppColor.grey.withOpacity(0.35),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _TopHeader extends StatelessWidget {
  const _TopHeader({required this.controller});

  final TasksController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF7C8CF8),
            Color(0xFF5B6BE6),
            Color(0xFF3D48B5),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF5B6BE6).withOpacity(0.30),
            blurRadius: 30,
            offset: const Offset(0, 16),
            spreadRadius: -18,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.16),
                  ),
                ),
                child: const Icon(
                  Icons.task_alt_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppString.task.tr,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${controller.filteredTasks.length} ${AppString.allTasks.tr.toLowerCase()}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.white.withOpacity(0.82),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _TaskFilterBar(controller: controller),
        ],
      ),
    );
  }
}

class _TaskFilterBar extends StatelessWidget {
  const _TaskFilterBar({required this.controller});

  final TasksController controller;

  @override
  Widget build(BuildContext context) {
    final filters = [
      _FilterData(
        filter: TaskFilter.all,
        label: AppString.allTasks.tr,
        icon: Icons.grid_view_rounded,
      ),
      _FilterData(
        filter: TaskFilter.queue,
        label: AppString.taskInQueue.tr,
        icon: Icons.hourglass_top_rounded,
      ),
      _FilterData(
        filter: TaskFilter.progress,
        label: AppString.taskInProgress.tr,
        icon: Icons.autorenew_rounded,
      ),
      _FilterData(
        filter: TaskFilter.completed,
        label: AppString.taskCompleted.tr,
        icon: Icons.verified_rounded,
      ),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: filters.map((item) {
          final selected = controller.selectedFilter.value == item.filter;

          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: ChoiceChip(
              selected: selected,
              onSelected: (_) => controller.setFilter(item.filter),
              showCheckmark: false,
              avatar: Icon(
                item.icon,
                size: 16,
                color: selected ? const Color(0xFF3D48B5) : Colors.white,
              ),
              label: Text(item.label),
              labelStyle: TextStyle(
                color: selected ? const Color(0xFF3D48B5) : Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
              selectedColor: Colors.white,
              backgroundColor: Colors.white.withOpacity(0.14),
              side: BorderSide(
                color: selected
                    ? Colors.transparent
                    : Colors.white.withOpacity(0.18),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _FilterData {
  const _FilterData({
    required this.filter,
    required this.label,
    required this.icon,
  });

  final TaskFilter filter;
  final String label;
  final IconData icon;
}

class _EmptyShell extends StatelessWidget {
  const _EmptyShell({
    required this.icon,
    required this.action,
  });

  final IconData icon;
  final Widget action;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: AppColor.grey.withOpacity(0.14),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF4F46E5).withOpacity(0.07),
            blurRadius: 28,
            offset: const Offset(0, 16),
            spreadRadius: -18,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  Color(0xFFEEF2FF),
                  Color(0xFFE4EAFF),
                ],
              ),
              border: Border.all(
                color: const Color(0xFF4F46E5).withOpacity(0.12),
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF4F46E5).withOpacity(0.12),
                  blurRadius: 18,
                  offset: const Offset(0, 10),
                  spreadRadius: -12,
                ),
              ],
            ),
            child: Icon(
              icon,
              size: 40,
              color: const Color(0xFF4F46E5),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            AppString.noTasksAvailable.tr,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
              color: AppColor.black,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            AppString.updateDataOrSendNew.tr,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColor.blackLight,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 22),
          action,
        ],
      ),
    );
  }
}

class _FilteredEmptyState extends StatelessWidget {
  const _FilteredEmptyState({required this.onClearFilter});

  final VoidCallback onClearFilter;

  @override
  Widget build(BuildContext context) {
    return _EmptyShell(
      icon: Icons.filter_alt_off_rounded,
      action: OutlinedButton.icon(
        onPressed: onClearFilter,
        icon: const Icon(Icons.clear_rounded, size: 18),
        label: Text(AppString.allTasks.tr),
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF4F46E5),
          backgroundColor: const Color(0xFF4F46E5).withOpacity(0.04),
          side: BorderSide(
            color: const Color(0xFF4F46E5).withOpacity(0.6),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}

class _EmptyTasksState extends StatelessWidget {
  const _EmptyTasksState({required this.onRefresh});

  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    return _EmptyShell(
      icon: Icons.task_alt_rounded,
      action: ElevatedButton.icon(
        onPressed: () => onRefresh(),
        icon: const Icon(Icons.refresh_rounded, size: 18),
        label: Text(AppString.refresh.tr),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF4F46E5),
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}