import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:career/core/constant/class/app_color.dart';
import 'package:career/core/constant/class/app_string.dart';
import 'package:career/features/tasks/data/model/task_model.dart';

class TaskDetailsScreen extends StatefulWidget {
  final TaskModel? task;
  final ValueChanged<String>? onStatusChanged;

  const TaskDetailsScreen({
    super.key,
    this.task,
    this.onStatusChanged,
  });

  @override
  State<TaskDetailsScreen> createState() => _TaskDetailsScreenState();
}

class _TaskDetailsScreenState extends State<TaskDetailsScreen> {
  TaskModel? _task;
  String? _selectedStatus;

  @override
  void initState() {
    super.initState();
    _task = widget.task ?? _getTaskFromArguments();
    _selectedStatus = _task?.status;
  }

  void _changeStatus(String status) {
    if (_selectedStatus == status) return;

    setState(() {
      _selectedStatus = status;
    });

    widget.onStatusChanged?.call(status);
  }

  @override
  Widget build(BuildContext context) {
    final taskData = _task;

    if (taskData == null) {
      return Scaffold(
        backgroundColor: const Color(0xFFF6F8FC),
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            onPressed: () => Get.back(),
            icon: const Icon(
              Icons.arrow_back_ios_rounded,
              color: Colors.black,
              size: 20,
            ),
          ),
        ),
        body: const Center(
          child: Text(
            'Task not found',
            style: TextStyle(
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      );
    }

    final statusStage = _statusStageFromValue(
      _selectedStatus,
      fallback: taskData.statusStage,
    );

    final statusColor = _statusColorFromStage(statusStage);

    final statusText = _statusTextFromValue(
      _selectedStatus,
      fallbackKey: taskData.statusTranslationKey,
    );

    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FC),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.black,
            size: 20,
          ),
        ),
        title: Text(
          AppString.task.tr,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
            color: AppColor.black,
          ),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _HeaderCard(
              task: taskData,
              statusColor: statusColor,
              statusText: statusText,
            ),
            const SizedBox(height: 16),
            _DetailsCard(
              task: taskData,
              statusColor: statusColor,
              statusText: statusText,
            ),
            const SizedBox(height: 16),
            _StatusChangeCard(
              options: _taskStatusOptions(),
              selectedStatus: _selectedStatus,
              activeColor: statusColor,
              enabled: widget.onStatusChanged != null,
              onSelected: _changeStatus,
            ),
            const SizedBox(height: 16),
            _TimelineCard(
              task: taskData,
              statusColor: statusColor,
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  TaskModel? _getTaskFromArguments() {
    final arguments = Get.arguments;

    if (arguments is TaskModel) {
      return arguments;
    }

    if (arguments is Map && arguments['task'] is TaskModel) {
      return arguments['task'] as TaskModel;
    }

    return null;
  }
}

List<_TaskStatusOption> _taskStatusOptions() {
  return const [
    _TaskStatusOption(
      value: 'In Queue',
      label: AppString.taskInQueue,
      stage: 0,
    ),
    _TaskStatusOption(
      value: 'In Progress',
      label: AppString.taskInProgress,
      stage: 1,
    ),
    _TaskStatusOption(
      value: 'Completed',
      label: AppString.taskCompleted,
      stage: 2,
    ),
  ];
}

Color _statusColorFromStage(int status) {
  switch (status) {
    case 0:
      return const Color(0xFFF59E0B);
    case 1:
      return const Color(0xFF2563EB);
    default:
      return const Color(0xFF16A34A);
  }
}

String _statusTextFromKey(String key) {
  switch (key) {
    case 'taskCompleted':
      return AppString.taskCompleted.tr;
    case 'taskInProgress':
      return AppString.taskInProgress.tr;
    case 'taskInQueue':
      return AppString.taskInQueue.tr;
    default:
      return AppString.taskUnknown.tr;
  }
}

int _statusStageFromValue(
    String? value, {
      required int fallback,
    }) {
  switch (value) {
    case 'In Queue':
      return 0;
    case 'In Progress':
      return 1;
    case 'Completed':
      return 2;
    default:
      return fallback;
  }
}

String _statusTextFromValue(
    String? value, {
      required String fallbackKey,
    }) {
  switch (value) {
    case 'In Queue':
      return AppString.taskInQueue.tr;
    case 'In Progress':
      return AppString.taskInProgress.tr;
    case 'Completed':
      return AppString.taskCompleted.tr;
    default:
      return _statusTextFromKey(fallbackKey);
  }
}

class _HeaderCard extends StatelessWidget {
  const _HeaderCard({
    required this.task,
    required this.statusColor,
    required this.statusText,
  });

  final TaskModel task;
  final Color statusColor;
  final String statusText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: statusColor.withOpacity(0.14),
        ),
        boxShadow: [
          BoxShadow(
            color: statusColor.withOpacity(0.10),
            blurRadius: 24,
            offset: const Offset(0, 14),
            spreadRadius: -18,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _StatusBadge(
                label: statusText,
                color: statusColor,
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: AppColor.grey.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '#${task.id}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: AppColor.blackLight,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            task.title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w900,
              color: AppColor.black,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            task.description.isEmpty ? '-' : task.description,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColor.blackLight,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailsCard extends StatelessWidget {
  const _DetailsCard({
    required this.task,
    required this.statusColor,
    required this.statusText,
  });

  final TaskModel task;
  final Color statusColor;
  final String statusText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: AppColor.grey.withOpacity(0.12),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionTitle(
            icon: Icons.info_outline_rounded,
            title: AppString.task.tr,
            color: AppColor.primaryColor,
          ),
          const SizedBox(height: 8),
          _InfoRow(
            label: AppString.taskStatus.tr,
            value: statusText,
            valueColor: statusColor,
          ),
          _InfoRow(
            label: AppString.assignedBy.tr,
            value: _firstNonEmpty([
              task.assignedBy,
              task.assignedByUsername,
            ]),
          ),
          _InfoRow(
            label: AppString.employee.tr,
            value: _firstNonEmpty([
              task.employeeName,
              task.employeeId.toString(),
            ]),
          ),
          _InfoRow(
            label: AppString.department.tr,
            value: task.departmentName.isNotEmpty
                ? task.departmentName
                : '-',
          ),
          _InfoRow(
            label: AppString.startDate.tr,
            value: task.startDateLabel.isNotEmpty
                ? task.startDateLabel
                : '-',
          ),
          _InfoRow(
            label: AppString.endDate.tr,
            value: task.endDateLabel.isNotEmpty
                ? task.endDateLabel
                : '-',
            isLast: true,
          ),
        ],
      ),
    );
  }

  String _firstNonEmpty(List<String> values) {
    for (final value in values) {
      final trimmed = value.trim();

      if (trimmed.isNotEmpty &&
          trimmed != '-' &&
          trimmed.toLowerCase() != 'null') {
        return value;
      }
    }

    return '-';
  }
}

class _StatusChangeCard extends StatelessWidget {
  const _StatusChangeCard({
    required this.options,
    required this.selectedStatus,
    required this.activeColor,
    required this.enabled,
    required this.onSelected,
  });

  final List<_TaskStatusOption> options;
  final String? selectedStatus;
  final Color activeColor;
  final bool enabled;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: activeColor.withOpacity(0.12),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionTitle(
            icon: Icons.tune_rounded,
            title: AppString.taskStatus.tr,
            color: activeColor,
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: options.map((option) {
              final selected = option.value == selectedStatus;
              final optionColor = _statusColorFromStage(option.stage);

              return ChoiceChip(
                selected: selected,
                showCheckmark: false,
                onSelected: enabled && !selected
                    ? (_) => onSelected(option.value)
                    : null,
                label: Text(option.label.tr),
                labelStyle: TextStyle(
                  color: selected ? Colors.white : optionColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
                selectedColor: optionColor,
                backgroundColor: optionColor.withOpacity(0.08),
                side: BorderSide(
                  color: optionColor.withOpacity(selected ? 0 : 0.25),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999),
                ),
              );
            }).toList(),
          ),
          if (!enabled)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                '-',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColor.blackLight,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _TimelineCard extends StatelessWidget {
  const _TimelineCard({
    required this.task,
    required this.statusColor,
  });

  final TaskModel task;
  final Color statusColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: AppColor.grey.withOpacity(0.12),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionTitle(
            icon: Icons.timeline_rounded,
            title: AppString.taskTimeline.tr,
            color: statusColor,
          ),
          const SizedBox(height: 16),
          _TimelineItem(
            label: AppString.startDate.tr,
            value: task.startDateLabel.isNotEmpty
                ? task.startDateLabel
                : '-',
            icon: Icons.play_arrow_rounded,
            color: AppColor.primaryColor,
          ),
          const SizedBox(height: 14),
          _TimelineItem(
            label: AppString.endDate.tr,
            value: task.endDateLabel.isNotEmpty
                ? task.endDateLabel
                : '-',
            icon: Icons.flag_rounded,
            color: statusColor,
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.icon,
    required this.title,
    required this.color,
  });

  final IconData icon;
  final String title;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            size: 18,
            color: color,
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w900,
            color: AppColor.black,
          ),
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.valueColor,
    this.isLast = false,
  });

  final String label;
  final String value;
  final Color? valueColor;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: isLast
                ? Colors.transparent
                : AppColor.grey.withOpacity(0.10),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColor.blackLight,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w800,
                color: valueColor ?? AppColor.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TimelineItem extends StatelessWidget {
  const _TimelineItem({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withOpacity(0.18),
            ),
          ),
          child: Icon(
            icon,
            size: 20,
            color: color,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColor.blackLight,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: AppColor.black,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({
    required this.label,
    required this.color,
  });

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 150),
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: color.withOpacity(0.16),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: color,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskStatusOption {
  const _TaskStatusOption({
    required this.value,
    required this.label,
    required this.stage,
  });

  final String value;
  final String label;
  final int stage;
}