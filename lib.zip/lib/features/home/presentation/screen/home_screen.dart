import 'package:career/core/constant/class/app_color.dart';
import 'package:career/core/constant/class/app_size.dart';
import 'package:career/core/constant/class/app_string.dart';
import 'package:career/core/router/routes_name.dart';
import 'package:career/features/home/presentation/widget/custom_button_sign.dart';
import 'package:career/features/home/presentation/widget/custom_card_home.dart';
import 'package:career/features/home/presentation/widget/statics.dart';
import 'package:career/features/home/presentation/widget/your_balance.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../getx/controller/home_controller.dart';
import '../widget/custom_home_app_bar.dart';
import '../widget/custom_slider.dart';

class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.scaffoldColor,
      floatingActionButton: _AssistantFab(),
      body: Column(
        children: [
          25.verticalSpace(),
          Obx(() => CustomHomeAppBar(name: controller.userDisplayName.value)),
          CustomSlider(),
          10.verticalSpace(),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                CustomButtonSign(),
                15.verticalSpace(),
                YourBalance(balance: '2000'),
                10.verticalSpace(),
                Statics(sale: '20', point: '100'),

                Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 0.06.w(context),
                      vertical: 0.02.h(context),
                    ),
                    child:_SectionHeader(title: AppString.more, icon: Icons.apps_rounded,)
                ),

                GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  padding: EdgeInsets.all(0.02.h(context)),
                  childAspectRatio: 0.9,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.vacation);
                      },
                      icon: Icons.beach_access,
                      title: AppString.vacations.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.myCourses);
                      },
                      icon: Icons.menu_book_rounded,
                      title: AppString.myCourses.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.task);
                      },
                      icon: Icons.checklist,
                      title: AppString.tasks.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.attendanceHistory);
                      },
                      icon: Icons.calendar_today,
                      title: AppString.attendanceSchedule.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.complaints);
                      },
                      icon: Icons.campaign_outlined,
                      title: AppString.complaints.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.employeeEvaluation);
                      },
                      icon: Icons.badge_outlined,
                      title: AppString.employeeEvaluation.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.overtimeRequests);
                      },
                      icon: Icons.access_time_rounded,
                      title: AppString.overtimeRequests.tr,
                      subtitle: AppString.requestOvertime.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.payrolls);
                      },
                      icon: Icons.payments_outlined,
                      title: AppString.payrolls.tr,
                      subtitle: AppString.viewDetails.tr,
                    ),
                    CustomCardHome(
                      onTap: () {
                        Get.toNamed(RoutesName.salaryPolicies);
                      },
                      icon: Icons.policy_outlined,
                      title: AppString.salaryPolicies.tr,
                      subtitle: AppString.salaryPolicyDetails.tr,
                    ),
                    // CustomCardHome(
                    //   onTap: () {
                    //     Get.toNamed(RoutesName.savingCards);
                    //   },
                    //   icon: Icons.savings_outlined,
                    //   title: AppString.savings.tr,
                    //   subtitle: AppString.viewDetails.tr,
                    // ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
class _AssistantFab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () => Get.toNamed(RoutesName.chatbot),
      backgroundColor: AppColor.primaryColor,
      foregroundColor: Colors.white,
      elevation: 4,
      icon: const Icon(Icons.smart_toy_rounded),
      label: Text(
        AppString.assistant.tr,
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.icon,
  });

  final String title;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppColor.primaryColor.withOpacity(0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            size: 18,
            color: AppColor.primaryColor,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppColor.primaryColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 2,
          child: Container(
            height: 2,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              gradient: LinearGradient(
                colors: [
                  AppColor.primaryColor.withOpacity(0.25),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}