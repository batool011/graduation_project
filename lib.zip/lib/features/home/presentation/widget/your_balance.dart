import 'package:career/core/constant/class/app_string.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:lottie/lottie.dart';
import '../../../../core/constant/class/app_asset.dart';
import '../../../../core/constant/class/app_color.dart';
import '../../../../core/constant/class/app_size.dart';

class YourBalance extends StatelessWidget {
  final String balance;
  const YourBalance({super.key, required this.balance});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 0.06.w(context)),
      padding: EdgeInsets.symmetric(
          horizontal: 0.06.w(context)
      ),
      decoration: BoxDecoration(
        color: AppColor.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(30),
            blurRadius: 10,
            spreadRadius: 2,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [

          Text(
            AppString.yourbalance.tr,
            style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              color: AppColor.primaryColor.withAlpha(120),
              fontWeight: FontWeight.w800,
            ),
          ),
          Text(
            balance,
            style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              color: AppColor.primaryColor.withAlpha(120),
              fontWeight: FontWeight.w800,
            ),
          ),
          Lottie.asset(AppAsset.savingMoney,height: 0.13.h(context))
        ],
      ),
    );
  }
}
