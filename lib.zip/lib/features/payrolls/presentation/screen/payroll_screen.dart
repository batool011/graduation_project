import 'package:career/core/constant/class/app_color.dart';
import 'package:career/core/constant/class/app_string.dart';
import 'package:career/core/widget/custom_app_bar.dart';
import 'package:career/features/payrolls/data/models/payroll_model.dart';
import 'package:career/features/payrolls/presentation/getx/controller/payroll_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

const Color _ink = Color(0xFF0F172A);
const Color _subInk = Color(0xFF64748B);
const Color _blue = Color(0xFF2563EB);
const Color _sky = Color(0xFF0EA5E9);
const Color _softBorder = Color(0xFFE5EAF3);
const Color _softBackground = Color(0xFFF8FAFC);

LinearGradient _brandGradient({
  AlignmentGeometry begin = Alignment.topLeft,
  AlignmentGeometry end = Alignment.bottomRight,
}) {
  return LinearGradient(
    colors: const [
      Color(0xFF4353A5),
      AppColor.primaryColor,
      Color(0xFF8CA3F5),
    ],
    begin: begin,
    end: end,
  );
}

class PayrollScreen extends GetView<PayrollController> {
  const PayrollScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      appBar: PreferredSize(
        preferredSize: const Size(double.infinity, 70),
        child: CustomAppBar(text: AppString.payrolls.tr),
      ),
      body: SafeArea(
        child: Obx(() {
          if (controller.isLoading.value && controller.payrolls.isEmpty) {
            return const _LoadingState();
          }

          return RefreshIndicator(
            color: AppColor.primaryColor,
            onRefresh: controller.refreshPayrolls,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
              children: [
                _PayrollHero(
                  totalCount: controller.paginationMeta.value?.total ??
                      controller.payrolls.length,
                  perPage: controller.perPage.value,
                  availableMonths: controller.availableMonths,
                  selectedMonth: controller.selectedMonth.value,
                  availableYears: controller.availableYears,
                  selectedYear: controller.selectedYear.value,
                  onMonthChanged: (month) {
                    if (month != null) {
                      controller.updatePeriod(
                        month: month,
                        year: controller.selectedYear.value,
                      );
                    }
                  },
                  onYearChanged: (year) {
                    if (year != null) {
                      controller.updatePeriod(
                        month: controller.selectedMonth.value,
                        year: year,
                      );
                    }
                  },
                ),
                const SizedBox(height: 18),
                if (controller.payrolls.isEmpty)
                  _EmptyPayrollState(onRefresh: controller.refreshPayrolls)
                else
                  ...controller.payrolls.map(
                        (record) => Padding(
                      padding: const EdgeInsets.only(bottom: 18),
                      child: _PayrollRecordCard(record: record),
                    ),
                  ),
                const SizedBox(height: 24),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _LoadingState extends StatelessWidget {
  const _LoadingState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 54,
        height: 54,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _softBorder),
          boxShadow: [
            BoxShadow(
              color: _ink.withOpacity(0.06),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Center(
          child: SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(
              strokeWidth: 2.6,
              color: AppColor.primaryColor,
            ),
          ),
        ),
      ),
    );
  }
}

class _DecorCircle extends StatelessWidget {
  const _DecorCircle({
    required this.size,
    required this.opacity,
    this.color = Colors.white,
  });

  final double size;
  final double opacity;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(opacity),
      ),
    );
  }
}
class _PayrollHero extends StatelessWidget {
  const _PayrollHero({
    required this.totalCount,
    required this.perPage,
    required this.availableMonths,
    required this.selectedMonth,
    required this.availableYears,
    required this.selectedYear,
    required this.onMonthChanged,
    required this.onYearChanged,
  });

  final int totalCount;
  final int perPage;
  final List<String> availableMonths;
  final int selectedMonth;
  final List<int> availableYears;
  final int selectedYear;

  final ValueChanged<int?> onMonthChanged;
  final ValueChanged<int?> onYearChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: _brandGradient(),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: AppColor.primaryColor.withOpacity(0.25),
            blurRadius: 30,
            offset: const Offset(0, 18),
            spreadRadius: -18,
          ),
        ],
      ),
      child: Stack(
        children: [
          const Positioned(
            right: -30,
            top: -24,
            child: _DecorCircle(size: 135, opacity: 0.10),
          ),
          const Positioned(
            left: -32,
            bottom: -26,
            child: _DecorCircle(size: 96, opacity: 0.08),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withOpacity(0.16)),
                    ),
                    child: const Icon(
                      Icons.payments_rounded,
                      color: Colors.white,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          AppString.payrollSummary.tr,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${AppString.month.tr}: ${availableMonths[selectedMonth - 1]} $selectedYear',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(
                            color: Colors.white.withOpacity(0.85),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _HeroDropdown<int>(
                      icon: Icons.calendar_month_rounded,
                      value: selectedMonth,
                      items: List.generate(12, (i) => i + 1),
                      labels: availableMonths,
                      onChanged: onMonthChanged,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _HeroDropdown<int>(
                      icon: Icons.calendar_today_rounded,
                      value: selectedYear,
                      items: availableYears,
                      labels: availableYears.map((e) => e.toString()).toList(),
                      onChanged: onYearChanged,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _HeroStat(
                      icon: Icons.receipt_long_rounded,
                      value: '$totalCount',
                      label: AppString.record.tr,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _HeroStat(
                      icon: Icons.view_list_rounded,
                      value: '$perPage',
                      label: AppString.perPage.tr,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroDropdown<T> extends StatelessWidget {
  const _HeroDropdown({
    required this.icon,
    required this.value,
    required this.items,
    required this.labels,
    required this.onChanged,
  });

  final IconData icon;
  final T value;
  final List<T> items;
  final List<String> labels;
  final ValueChanged<T?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.14),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.18)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white.withOpacity(0.9), size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<T>(
                value: value,
                isExpanded: true,
                isDense: true,
                dropdownColor: Colors.white,
                borderRadius: BorderRadius.circular(16),
                icon: const Icon(Icons.keyboard_arrow_down_rounded,
                    color: Colors.white),
                style: const TextStyle(
                    color: _ink, fontWeight: FontWeight.w700, fontSize: 14),
                selectedItemBuilder: (context) {
                  return labels.map((label) {
                    return Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    );
                  }).toList();
                },
                items: List.generate(items.length, (index) {
                  return DropdownMenuItem<T>(
                    value: items[index],
                    child: Text(
                      labels[index],
                      style: const TextStyle(
                          color: _ink,
                          fontWeight: FontWeight.w600,
                          fontSize: 14),
                    ),
                  );
                }),
                onChanged: onChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  const _HeroStat({
    required this.icon,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.16)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 17),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    value,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.white.withOpacity(0.8),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PayrollRecordCard extends StatefulWidget {
  const _PayrollRecordCard({required this.record});

  final PayrollRecord record;

  @override
  State<_PayrollRecordCard> createState() => _PayrollRecordCardState();
}

class _PayrollRecordCardState extends State<_PayrollRecordCard> {
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    final record = widget.record;

    final tabs = <String>[
      AppString.payrollSummary.tr,
      AppString.payrollRates.tr,
      AppString.deductions.tr,
      AppString.payrollDetails.tr,
    ];

    final counts = <int?>[
      null,
      null,
      record.deductions.length,
      record.details.length,
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _softBorder),
        boxShadow: [
          BoxShadow(
            color: _ink.withOpacity(0.06),
            blurRadius: 24,
            offset: const Offset(0, 14),
            spreadRadius: -16,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          children: [
            Positioned(
              top: -56,
              right: -34,
              child: _DecorCircle(
                size: 140,
                opacity: 0.05,
                color: _blue,
              ),
            ),
            Positioned(
              bottom: -48,
              left: -30,
              child: _DecorCircle(
                size: 110,
                opacity: 0.05,
                color: _sky,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              gradient: _brandGradient(),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                  AppColor.primaryColor.withOpacity(0.22),
                                  blurRadius: 16,
                                  offset: const Offset(0, 10),
                                  spreadRadius: -10,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.account_balance_wallet_rounded,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  record.periodLabel,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(
                                    fontWeight: FontWeight.w900,
                                    color: _ink,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.calendar_month_rounded,
                                      size: 15,
                                      color: _subInk,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        '${AppString.month.tr}: ${record.periodLabel}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall
                                            ?.copyWith(
                                          color: _subInk,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          _AmountBadge(amount: record.netSalary),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _buildTabBar(tabs, counts),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    switchInCurve: Curves.easeOut,
                    switchOutCurve: Curves.easeIn,
                    transitionBuilder: (child, animation) {
                      return FadeTransition(
                        opacity: animation,
                        child: child,
                      );
                    },
                    child: KeyedSubtree(
                      key: ValueKey(_selectedTab),
                      child: _buildContent(context),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabBar(List<String> tabs, List<int?> counts) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _softBorder),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(
            tabs.length,
                (index) => Padding(
              padding: EdgeInsets.only(
                right: index == tabs.length - 1 ? 0 : 6,
              ),
              child: _PayrollTabButton(
                label: tabs[index],
                isActive: _selectedTab == index,
                count: counts[index],
                onTap: () {
                  setState(() {
                    _selectedTab = index;
                  });
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context) {
    switch (_selectedTab) {
      case 0:
        return _SummaryTab(record: widget.record);
      case 1:
        return _RatesTab(record: widget.record);
      case 2:
        return _DeductionsTab(record: widget.record);
      default:
        return _DetailsTab(record: widget.record);
    }
  }
}

class _PayrollTabButton extends StatelessWidget {
  const _PayrollTabButton({
    required this.label,
    required this.isActive,
    required this.onTap,
    this.count,
  });

  final String label;
  final bool isActive;
  final VoidCallback onTap;
  final int? count;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: isActive ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isActive
                  ? AppColor.primaryColor.withOpacity(0.14)
                  : Colors.transparent,
            ),
            boxShadow: isActive
                ? [
              BoxShadow(
                color: AppColor.primaryColor.withOpacity(0.10),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ]
                : [],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isActive ? AppColor.primaryColor : _subInk,
                  fontWeight: FontWeight.w800,
                ),
              ),
              if (count != null) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: isActive
                        ? AppColor.primaryColor.withOpacity(0.10)
                        : const Color(0xFFE2E8F0),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '${count ?? 0}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: isActive ? AppColor.primaryColor : _subInk,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryTab extends StatelessWidget {
  const _SummaryTab({required this.record});

  final PayrollRecord record;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            _InfoBadge(
              icon: Icons.calendar_month_outlined,
              label:
              '${AppString.calculatedAt.tr}: ${record.calculatedAtLabel}',
            ),
            const SizedBox(width: 8),
            _InfoBadge(
              icon: Icons.trending_down_rounded,
              label:
              '${AppString.totalDeduction.tr}: ${_formatMoney(record.totalDeduction)}',
            ),
          ],
        ),
        const SizedBox(height: 16),
        _SectionTitle(
          icon: Icons.dashboard_rounded,
          title: AppString.payrollSummary.tr,
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 700 ? 3 : 2;

            return GridView.count(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.26,
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              children: [
                _MetricTile(
                  label: AppString.basicSalary.tr,
                  value: _formatMoney(record.basicSalary),
                  icon: Icons.payments_outlined,
                ),
                _MetricTile(
                  label: AppString.workingDays.tr,
                  value: record.workingDays.toString(),
                  icon: Icons.calendar_month_outlined,
                ),
                _MetricTile(
                  label: AppString.presentDays.tr,
                  value: record.presentDays.toString(),
                  icon: Icons.check_circle_outline,
                ),
                _MetricTile(
                  label: AppString.absenceDays.tr,
                  value: record.absenceDays.toString(),
                  icon: Icons.do_not_disturb_on_outlined,
                ),
                _MetricTile(
                  label: AppString.unpaidLeaveDays.tr,
                  value: record.unpaidLeaveDays.toString(),
                  icon: Icons.event_busy_outlined,
                ),
                _MetricTile(
                  label: AppString.totalDeduction.tr,
                  value: _formatMoney(record.totalDeduction),
                  icon: Icons.remove_circle_outline,
                ),
                _MetricTile(
                  label: AppString.lateMinutes.tr,
                  value: record.lateMinutes.toString(),
                  icon: Icons.timer_outlined,
                ),
                _MetricTile(
                  label: AppString.earlyLeaveMinutes.tr,
                  value: record.earlyLeaveMinutes.toString(),
                  icon: Icons.exit_to_app_outlined,
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _RatesTab extends StatelessWidget {
  const _RatesTab({required this.record});

  final PayrollRecord record;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionTitle(
          icon: Icons.percent_rounded,
          title: AppString.payrollRates.tr,
        ),
        const SizedBox(height: 10),
        _RateCard(
          icon: Icons.today_rounded,
          label: AppString.dayRate.tr,
          value: _formatMoney(record.rates.dayRate, fractionDigits: 4),
        ),
        const SizedBox(height: 10),
        _RateCard(
          icon: Icons.schedule_rounded,
          label: AppString.hourRate.tr,
          value: _formatMoney(record.rates.hourRate, fractionDigits: 4),
        ),
        const SizedBox(height: 10),
        _RateCard(
          icon: Icons.more_time_rounded,
          label: AppString.minuteRate.tr,
          value: _formatMoney(record.rates.minuteRate, fractionDigits: 4),
        ),
      ],
    );
  }
}

class _DeductionsTab extends StatelessWidget {
  const _DeductionsTab({required this.record});

  final PayrollRecord record;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionTitle(
          icon: Icons.remove_circle_outline,
          title: AppString.deductions.tr,
          count: record.deductions.length,
        ),
        const SizedBox(height: 10),
        if (record.deductions.isEmpty)
          _EmptySectionBox(text: AppString.noData.tr)
        else
          Column(
            children: record.deductions
                .map(
                  (deduction) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _DeductionTile(deduction: deduction),
              ),
            )
                .toList(),
          ),
      ],
    );
  }
}

class _DetailsTab extends StatelessWidget {
  const _DetailsTab({required this.record});

  final PayrollRecord record;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionTitle(
          icon: Icons.event_note_rounded,
          title: AppString.payrollDetails.tr,
          count: record.details.length,
        ),
        const SizedBox(height: 10),
        if (record.details.isEmpty)
          _EmptySectionBox(text: AppString.noData.tr)
        else
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: record.details
                .map((detail) => _DetailChip(detail: detail))
                .toList(),
          ),
      ],
    );
  }
}

class _AmountBadge extends StatelessWidget {
  const _AmountBadge({required this.amount});

  final double amount;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: _brandGradient(),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColor.primaryColor.withOpacity(0.22),
            blurRadius: 16,
            offset: const Offset(0, 10),
            spreadRadius: -10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            AppString.netSalary.tr,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.white.withOpacity(0.8),
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              _formatMoney(amount),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoBadge extends StatelessWidget {
  const _InfoBadge({
    required this.icon,
    required this.label,
  });

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: _softBackground,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _softBorder),
        ),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: _blue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                size: 16,
                color: _blue,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                label,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: _ink,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _softBorder),
        boxShadow: [
          BoxShadow(
            color: _ink.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _blue.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              size: 18,
              color: _blue,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    value,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                      color: _ink,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: _subInk,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RateCard extends StatelessWidget {
  const _RateCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFEFF6FF),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _blue.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _blue.withOpacity(0.08)),
            ),
            child: Icon(icon, size: 18, color: _blue),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: _ink,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: _blue,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DeductionTile extends StatelessWidget {
  const _DeductionTile({required this.deduction});

  final PayrollDeduction deduction;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5F5),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFFECACA)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFDC2626).withOpacity(0.05),
            blurRadius: 14,
            offset: const Offset(0, 8),
            spreadRadius: -8,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFFEE2E2),
              border: Border.all(color: const Color(0xFFFECACA)),
            ),
            child: const Icon(
              Icons.remove_circle_outline,
              color: Color(0xFFDC2626),
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  deduction.policy.isEmpty ? '-' : deduction.policy,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFF7F1D1D),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${AppString.metric.tr}: ${_formatMoney(deduction.metric, fractionDigits: 4)} • ${AppString.metricUnit.tr}: ${deduction.metricUnit.isEmpty ? '-' : deduction.metricUnit}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: _subInk,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFFDC2626).withOpacity(0.08),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color: const Color(0xFFDC2626).withOpacity(0.12),
              ),
            ),
            child: Text(
              _formatMoney(deduction.amount),
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w900,
                color: const Color(0xFFB91C1C),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailChip extends StatelessWidget {
  const _DetailChip({required this.detail});

  final PayrollDetail detail;

  @override
  Widget build(BuildContext context) {
    final isPresent = detail.isPresent;
    final isAbsent = detail.isAbsent;

    final backgroundColor = isPresent
        ? const Color(0xFFEFFAF2)
        : isAbsent
        ? const Color(0xFFFFF1F2)
        : const Color(0xFFF8FAFC);

    final textColor = isPresent
        ? const Color(0xFF15803D)
        : isAbsent
        ? const Color(0xFFBE123C)
        : const Color(0xFF334155);

    final icon = isPresent
        ? Icons.check_circle_rounded
        : isAbsent
        ? Icons.cancel_rounded
        : Icons.event_rounded;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: textColor.withOpacity(0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: textColor,
          ),
          const SizedBox(width: 6),
          Text(
            '${detail.dateLabel} • ${detail.status}',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: textColor,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.title,
    required this.icon,
    this.count,
  });

  final String title;
  final IconData icon;
  final int? count;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: _blue.withOpacity(0.10),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            icon,
            size: 16,
            color: _blue,
          ),
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w900,
              color: _ink,
            ),
          ),
        ),
        if (count != null) ...[
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _blue.withOpacity(0.08),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              '${count ?? 0}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: _blue,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _softBorder,
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _EmptySectionBox extends StatelessWidget {
  const _EmptySectionBox({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _softBackground,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _softBorder),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 18,
            color: _subInk,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: _subInk,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyPayrollState extends StatelessWidget {
  const _EmptyPayrollState({required this.onRefresh});

  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: _softBorder),
        boxShadow: [
          BoxShadow(
            color: _ink.withOpacity(0.05),
            blurRadius: 24,
            offset: const Offset(0, 16),
            spreadRadius: -18,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 88,
            height: 88,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _brandGradient(),
              boxShadow: [
                BoxShadow(
                  color: AppColor.primaryColor.withOpacity(0.22),
                  blurRadius: 20,
                  offset: const Offset(0, 12),
                  spreadRadius: -12,
                ),
              ],
            ),
            child: const Icon(
              Icons.account_balance_wallet_rounded,
              color: Colors.white,
              size: 38,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            AppString.noPayrollData.tr,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
              color: _ink,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            AppString.refresh.tr,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: _subInk,
            ),
          ),
          const SizedBox(height: 22),
          Container(
            height: 46,
            decoration: BoxDecoration(
              gradient: _brandGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: AppColor.primaryColor.withOpacity(0.22),
                  blurRadius: 14,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => onRefresh(),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.refresh_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        AppString.refresh.tr,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _formatMoney(num value, {int fractionDigits = 0}) {
  final fixed = value.toStringAsFixed(fractionDigits);

  if (fractionDigits == 0) {
    return fixed;
  }

  return fixed.replaceFirst(RegExp(r'\.?0+$'), '');
}