import 'package:career/core/router/routes_name.dart';
import 'package:career/features/auth/presentation/getx/binding/auth_binding.dart';
import 'package:career/features/auth/presentation/screen/log_in_screen.dart';
import 'package:career/features/auth/presentation/screen/register_screen.dart';
import 'package:career/features/complaints/presentation/getx/binding/complaints_binding.dart';
import 'package:career/features/complaints/presentation/screen/complaints_screen.dart';
import 'package:career/features/courses/presentation/getx/binding/courses_binding.dart';
import 'package:career/features/courses/presentation/screens/my_courses_screen.dart';
import 'package:career/features/attendance_history/presentation/getx/binding/attendance_history_binding.dart';
import 'package:career/features/attendance_history/presentation/screen/attendance_history_screen.dart';
import 'package:career/features/notification/presentation/getx/binding/notification_binding.dart';
import 'package:career/features/notification/presentation/screen/notification_screen.dart';
import 'package:career/features/employee_evaluation/presentation/getx/binding/employee_evaluation_binding.dart';
import 'package:career/features/employee_evaluation/presentation/screen/employee_evaluation_screen.dart';
import 'package:career/features/on%20boarding/presentation/getx/binding/onboarding_binding.dart';
import 'package:career/features/on%20boarding/presentation/screen/on_boarding_screen.dart';
import 'package:career/features/payrolls/presentation/getx/binding/payroll_binding.dart';
import 'package:career/features/payrolls/presentation/screen/payroll_screen.dart';
import 'package:career/features/overtime_requests/presentation/getx/binding/overtime_binding.dart';
import 'package:career/features/overtime_requests/presentation/screen/overtime_screen.dart';
import 'package:career/features/salary_policies/presentation/getx/binding/salary_policies_binding.dart';
import 'package:career/features/salary_policies/presentation/screen/salary_policies_screen.dart';
import 'package:career/features/profile/presentation/getx/binding/profile_binding.dart';
import 'package:career/features/profile/presentation/screens/profile_screen.dart';
import 'package:career/features/saving_money/presentation/binding/savings_binding.dart';
import 'package:career/features/saving_money/presentation/screens/saving_card_details_screen.dart';
import 'package:career/features/saving_money/presentation/screens/saving_money_cards_screen.dart';
import 'package:career/features/saving_money/presentation/screens/subscription_plan_screen.dart';
import 'package:career/features/setting/presentation/screen/about_app_screen.dart';
import 'package:career/features/setting/presentation/getx/binding/setting_binding.dart';
import 'package:career/features/setting/presentation/screen/help_center_screen.dart';
import 'package:career/features/setting/presentation/screen/setting_screen.dart';
import 'package:career/features/splash/presentation/screen/splash_screen.dart';
import 'package:career/features/tasks/presentation/getx/binding/tasks_binding.dart';
import 'package:career/features/tasks/presentation/screen/tasks_screen.dart';
import 'package:career/features/vacation/presentation/screen/vacation_screen.dart';
import 'package:career/features/vacation/presentation/screen/vacation_requests_screen.dart';
import 'package:career/features/vacation/presentation/screen/vacation_request_detail_screen.dart';
import 'package:get/get.dart';
import '../../chatbot/presentation/getx/binding/chatbot_binding.dart';
import '../../chatbot/presentation/screens/chatbot_screen.dart';
import '../../features/app-main/presentation/getx/main_binding.dart';
import '../../features/app-main/presentation/screens/main_screen.dart';
import '../../features/splash/presentation/getx/binding/splash_binding.dart';
import '../../features/vacation/presentation/getx/binding/vacation_binding.dart';

class AppRoute {
  static final routes = [
    GetPage(
      name: RoutesName.splash,
      page: () => const SplashScreen(),
      binding: SplashBinding(),
    ),
    GetPage(
      name: RoutesName.onBoarding,
      page: () => const OnBoardingScreen(),
      binding: OnBoardingBinding(),
    ),
    GetPage(
      name: RoutesName.login,
      page: () => const LogInScreen(),
      binding: AuthBinding(),
    ),

    GetPage(
      name: RoutesName.register,
      page: () => const RegisterScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: RoutesName.home,
      page: () => MainScreen(),
      binding: MainBinding(),
    ),

    GetPage(
      name: RoutesName.setting,
      page: () => SettingScreen(),
      binding: SettingBinding(),
    ),
    GetPage(
      name: RoutesName.profile,
      page: () => ProfileScreen(),
      binding: ProfileBinding(),
    ),

    GetPage(
      name: RoutesName.notification,
      page: () => const NotificationScreen(),
      binding: NotificationBinding(),
    ),
    GetPage(
      name: RoutesName.employeeEvaluation,
      page: () => const EmployeeEvaluationScreen(),
      binding: EmployeeEvaluationBinding(),
    ),
    GetPage(
      name: RoutesName.payrolls,
      page: () => const PayrollScreen(),
      binding: PayrollBinding(),
    ),
    GetPage(
      name: RoutesName.overtimeRequests,
      page: () => const OvertimeScreen(),
      binding: OvertimeBinding(),
    ),
    GetPage(
      name: RoutesName.salaryPolicies,
      page: () => const SalaryPoliciesScreen(),
      binding: SalaryPoliciesBinding(),
    ),
    GetPage(
      name: RoutesName.vacation,
      page: () => const VacationScreen(),
      binding: VacationBinding(),
    ),
    GetPage(
      name: RoutesName.vacationRequests,
      page: () => const VacationRequestsScreen(),
      binding: VacationBinding(),
    ),
    GetPage(
      name: RoutesName.vacationRequestDetails,
      page: () => const VacationRequestDetailScreen(),
      binding: VacationBinding(),
    ),
    GetPage(
      name: RoutesName.attendanceHistory,
      page: () => const AttendanceHistoryScreen(),
      binding: AttendanceHistoryBinding(),
    ),

    //الادخااار
    GetPage(
      name: RoutesName.savingCards,
      page: () => SavingsCardsScreen(),
      binding: SavingsBinding(),
    ),
    GetPage(
      name: RoutesName.savingCardsDetails,
      page: () => SavingsCardDetailsScreen(card: Get.arguments),
      binding: SavingsBinding(),
    ),
    GetPage(
      name: RoutesName.subscriptionPlans,
      page: () => SubscriptionPlansScreen(card: Get.arguments),
      binding: SavingsBinding(),
    ),
    GetPage(
      name: RoutesName.aboutApp,
      page: () => AboutAppScreen(),
      //  binding: SavingsBinding(),
    ),
    GetPage(
      name: RoutesName.helpCenter,
      page: () => HelpCenterScreen(),
      //binding: SavingsBinding(),
    ),
    GetPage(
      name: RoutesName.task,
      page: () => TasksScreen(),
      binding: TasksBinding(),
    ),
    GetPage(
      name: RoutesName.complaints,
      page: () => const ComplaintsScreen(),
      binding: ComplaintsBinding(),
    ),
    GetPage(
      name: RoutesName.myCourses,
      page: () => const MyCoursesScreen(),
      binding: CoursesBinding(),
    ),
    GetPage(
      name: RoutesName.chatbot,
      page: () => const ChatbotScreen(),
      binding: ChatbotBinding(),
    ),
  ];
}
